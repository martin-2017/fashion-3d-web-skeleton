import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import bodyParser from 'body-parser'
import { ApolloServer, gql } from 'apollo-server-express'

const typeDefs = gql`
  type Component { id: ID!, style: String!, gltfUri: String! }
  type PublishResult { version: String!, bomUrl: String!, routingUrl: String!, patterns: [Pattern!]! }
  type Pattern { size: String!, url: String! }

  type Query {
    components(category: String!): [Component!]!
  }
  type Mutation {
    publishDesign(id: ID!): PublishResult!
  }
`

const resolvers = {
  Query: {
    components: (_: any, { category }: { category: string }) => {
      // stub data
      return [
        { id: 'COLLAR_SPREAD_STD@v1.3.2', style: 'Spread', gltfUri: '/assets/collar_spread_std_v1_3_2.glb' }
      ]
    }
  },
  Mutation: {
    publishDesign: async (_: any, { id }: { id: string }) => {
      const s3Base = process.env.S3_BASE || 'https://example.com'
      return {
        version: 'v0.0.1',
        bomUrl: `${s3Base}/bom_${id}.csv`,
        routingUrl: `${s3Base}/routing_${id}.json`,
        patterns: [{ size: 'M', url: `${s3Base}/pattern_${id}_M.dxf` }]
      }
    }
  }
}

async function start() {
  const app = express()
  app.use(cors())
  app.use(bodyParser.json())

  // webhook stub
  app.post('/webhooks/design.published', (req, res) => {
    console.log('Webhook payload:', req.body)
    res.json({ ok: true })
  })

  const server = new ApolloServer({ typeDefs, resolvers })
  await server.start()
  server.applyMiddleware({ app, path: '/graphql' })

  const port = process.env.PORT || 4000
  app.listen(port, () => console.log(`Server at http://localhost:${port}`))
}

start()
