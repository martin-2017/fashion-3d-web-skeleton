#!/usr/bin/env node
// Stub: CLI to tag glTF with extras.anchor/constraints and validate LOD/bounds.
console.log("asset-tag: (stub) read glTF, add extras.anchor, validate, write out.");
