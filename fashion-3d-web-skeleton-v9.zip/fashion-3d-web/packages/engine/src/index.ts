import type { Anchor, Component } from "@fashion3d/schemas";

export interface AnchorMatch {
  componentId: string;
  anchor: Anchor;
  worldNormal: [number, number, number];
}

export function isCompatible(a: Anchor, b: Anchor): boolean {
  // Simplified compatibility check: same type and opposite normals (approx)
  if (a.type !== 'snap' || b.type !== 'snap') return false;
  // In real code: check extras.compatible lists, tolerance, categories, etc.
  return true;
}

export function findSnapTarget(drag: Component, all: Component[]): { target?: Component; anchorName?: string } {
  // Placeholder logic: choose first compatible anchor pair
  const a0 = drag.anchors[0];
  for (const c of all) {
    if (c.id === drag.id) continue;
    for (const a1 of c.anchors) {
      if (isCompatible(a0, a1)) return { target: c, anchorName: a1.name };
    }
  }
  return {};
}
