export type Vec3 = [number, number, number];

export type Category =
  | 'Collar' | 'Placket' | 'Sleeve' | 'Cuff' | 'Pocket' | 'Button'
  | 'Zipper' | 'Vent' | 'Yoke' | 'Dart' | 'Hem' | 'Lapel' | 'Hood' | 'Other';

export interface Anchor { name: string; type: 'snap'|'align'; normal: Vec3; tolerance_mm: number; }
export interface Param { min: number; max: number; step: number; default: number; unit?: 'mm'|'deg'; }
export interface Constraints { allowedBodies: string[]; forbidWith: string[]; fabricClasses: string[]; }
export interface PatternRef { dxf_uri: string; size: string; }
export interface SeamSpec { code: string; desc: string; stitch_len_mm: number; }
export interface BomLine { item_code: string; uom: 'm'|'pcs'|'set'|'g'; qty_per_unit: number; wastage_pct?: number; }

export interface Component {
  id: string;
  category: Category;
  style: string;
  gltfUri: string;
  anchors: Anchor[];
  parameters: Record<string, Param>;
  constraints: Constraints;
  patterns: PatternRef[];
  seams: SeamSpec[];
  bom: BomLine[];
}

export interface Operation {
  op_no: number;
  name: string;
  skill: string;
  machine: string;
  materials: string[];
  seam_code?: string;
  takt_time_sec: number;
  qc_points?: string[];
}

export interface DesignPackage {
  design_id: string;
  version: string;
  body: string;
  components: string[];
  parameters: Record<string, number|boolean|string>;
  bom: BomLine[];
  routing: Operation[];
  assets: { type: 'gltf'|'dxf'|'pdf'; url: string; }[];
}
