import Dexie, { Table } from 'dexie'

export interface Project {
  id: string
  createdAt: number
  updatedAt: number
  components: string[]
  placements: any[]
}

export class F3DDB extends Dexie {
  projects!: Table<Project, string>
  constructor() {
    super('f3d-db')
    this.version(2).stores({
      projects: 'id, updatedAt'
    })
  }
}

export const db = new F3DDB()
