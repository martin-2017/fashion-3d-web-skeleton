import * as Comlink from 'comlink'

const api = {
  calcBOM(components: string[]) {
    // placeholder: return fixed line items
    return [
      { component: "BUTTON_4HOLE_12MM", color: "White", uom: "pcs", qty_per: 8, wastage_pct: 3 }
    ]
  }
}

Comlink.expose(api)
