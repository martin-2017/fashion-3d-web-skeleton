// Minimal DXF ASCII parser (LINE/LWPOLYLINE) + seam length in worker
type Line = { type:'LINE', layer:string, x1:number,y1:number,x2:number,y2:number }
type Poly = { type:'LWPOLYLINE', layer:string, points:Array<[number,number]>, closed:boolean }
type DxfEntity = Line | Poly

function parseDxfAscii(text: string): DxfEntity[] {
  const lines = text.replace(/\r/g,'\n').split(/\n/).map(s=>s.trim())
  let i = 0
  const entities: DxfEntity[] = []
  function nextPair() {
    if (i >= lines.length) return null
    const code = lines[i++]; const value = lines[i++]
    if (value === undefined) return null
    return [code, value] as [string,string]
  }
  while (i < lines.length) {
    const pair = nextPair(); if (!pair) break
    const [code, value] = pair
    if (code === '0' && value === 'LWPOLYLINE') {
      let layer = '0'; let closed = false; const pts: Array<[number,number]> = []
      let lastCode = ''
      while (true) {
        const p = nextPair(); if (!p) break
        const [c, v] = p
        if (c === '0') { i -= 2; break }
        if (c === '8') layer = v
        if (c === '70') closed = (parseInt(v,10) & 1) === 1
        if (c === '10') { lastCode = c; pts.push([parseFloat(v), 0]) }
        if (c === '20' && lastCode === '10') { const last = pts[pts.length-1]; last[1] = parseFloat(v) }
      }
      entities.push({ type:'LWPOLYLINE', layer, points: pts, closed })
    } else if (code === '0' && value === 'LINE') {
      let layer = '0', x1=0,y1=0,x2=0,y2=0
      while (true) {
        const p = nextPair(); if (!p) break
        const [c, v] = p
        if (c === '0') { i -= 2; break }
        if (c === '8') layer = v
        if (c === '10') x1 = parseFloat(v)
        if (c === '20') y1 = parseFloat(v)
        if (c === '11') x2 = parseFloat(v)
        if (c === '21') y2 = parseFloat(v)
      }
      entities.push({ type:'LINE', layer, x1,y1,x2,y2 })
    }
  }
  return entities
}
function seamLength(ents: DxfEntity[]) {
  const seg = (x1:number,y1:number,x2:number,y2:number)=>Math.hypot(x2-x1, y2-y1)
  let total = 0
  for (const e of ents) {
    if (e.type==='LINE') total += seg(e.x1,e.y1,e.x2,e.y2)
    else {
      for (let i=1;i<e.points.length;i++) total += seg(e.points[i-1][0], e.points[i-1][1], e.points[i][0], e.points[i][1])
      if (e.closed && e.points.length>1) total += seg(e.points[0][0], e.points[0][1], e.points.at(-1)![0], e.points.at(-1)![1])
    }
  }
  return total
}

self.onmessage = async (ev: MessageEvent) => {
  const { type, url } = ev.data || {}
  if (type === 'computeSeam') {
    try {
      const txt = await (await fetch(url)).text()
      const ents = parseDxfAscii(txt)
      const total = seamLength(ents)
      ;(self as any).postMessage({ ok: true, total })
    } catch (e) {
      ;(self as any).postMessage({ ok: false, error: String(e) })
    }
  }
}
