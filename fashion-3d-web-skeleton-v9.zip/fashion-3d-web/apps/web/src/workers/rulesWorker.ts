type Ctx = { bodyType: string; fabricClass: string; presentTags: string[] }
type RuleSpec = any // JSONLogic-like

function evalLogic(rule: any, data: any): boolean {
  if (rule == null) return true
  if (typeof rule !== 'object' || Array.isArray(rule)) return !!rule
  const op = Object.keys(rule)[0]
  const val = rule[op]
  switch (op) {
    case 'and': return val.every((x:any)=>evalLogic(x,data))
    case 'or': return val.some((x:any)=>evalLogic(x,data))
    case '!': return !evalLogic(val, data)
    case '==': return evalLogic(val[0],data) == evalLogic(val[1],data)
    case 'in': {
      const el = evalLogic(val[0], data); const arr = evalLogic(val[1], data)
      return Array.isArray(arr) ? arr.includes(el) : false
    }
    case 'var': return val.split('.').reduce((o:any,k:string)=>o?.[k], data)
    case 'contains': {
      const arr = evalLogic(val[0],data); const el = evalLogic(val[1],data)
      return Array.isArray(arr) ? arr.includes(el) : false
    }
    default: return true
  }
}

let rules: Record<string, RuleSpec> = {}

self.onmessage = async (ev: MessageEvent) => {
  const { type, payload } = ev.data || {}
  if (type === 'load') {
    rules = payload || {}
    ;(self as any).postMessage({ type:'loaded', ok:true })
    return
  }
  if (type === 'check') {
    const { compId, ctx } = payload as { compId: string, ctx: Ctx }
    const cat = compId.startsWith('COLLAR') ? 'COLLAR' : compId.startsWith('POCKET') ? 'POCKET' : compId.startsWith('PLACKET') ? 'PLACKET' : 'OTHER'
    const rule = rules[cat]
    const ok = rule ? !!evalLogic(rule, { bodyType: ctx.bodyType, fabricClass: ctx.fabricClass, presentTags: ctx.presentTags }) : true
    ;(self as any).postMessage({ type:'result', ok, compId })
  }
}
