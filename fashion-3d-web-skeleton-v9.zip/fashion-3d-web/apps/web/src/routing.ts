export type Operation = {
  op_no: number
  name: string
  skill: string
  machine: string
  materials: string[]
  seam_code?: string
  takt_time_sec: number
  qc_points?: string[]
}

const ROUTING_MAP: Record<string, Operation[]> = {
  'COLLAR': [
    { op_no: 120, name: 'Attach collar', skill: 'Sew_A_Level2', machine: 'Lockstitch_1N_DL7500', materials: ['THREAD_60S_WHITE'], seam_code: 'SSa-1', takt_time_sec: 55, qc_points: ['seam_width','symmetry'] }
  ],
  'POCKET': [
    { op_no: 80, name: 'Attach pocket', skill: 'Sew_A_Level1', machine: 'Lockstitch_1N', materials: ['THREAD_60S_WHITE'], seam_code: 'SSa-1', takt_time_sec: 40, qc_points: ['alignment','topstitch'] }
  ],
  'PLACKET': [
    { op_no: 100, name: 'Attach placket', skill: 'Sew_A_Level2', machine: 'Lockstitch_1N', materials: ['THREAD_60S_WHITE'], seam_code: 'SSa-1', takt_time_sec: 50, qc_points: ['placket_width'] }
  ]
}

function keyFromComponent(id: string) {
  if (id.startsWith('COLLAR')) return 'COLLAR'
  if (id.startsWith('POCKET')) return 'POCKET'
  if (id.startsWith('PLACKET')) return 'PLACKET'
  return 'OTHER'
}

export function generateRouting(components: string[]): Operation[] {
  const ops: Operation[] = []
  const seen = new Set<string>()
  for (const c of components) {
    const k = keyFromComponent(c)
    const arr = ROUTING_MAP[k] || []
    for (const op of arr) {
      const sig = `${op.op_no}:${op.name}`
      if (seen.has(sig)) continue
      seen.add(sig)
      ops.push(op)
    }
  }
  // sort by op_no
  ops.sort((a,b)=>a.op_no-b.op_no)
  return ops
}
