export type RuleSpec = { allowedBodies?: string[]; forbidWith?: string[]; fabricClasses?: string[] }
export type RuleMap = Record<string, RuleSpec>

let CURRENT_RULES: RuleMap = {}

export function setRules(r: RuleMap) { CURRENT_RULES = r }
export function getRules() { return CURRENT_RULES }

export async function loadRulesFromUrl(url: string) {
  try {
    const res = await fetch(url)
    const json = await res.json()
    setRules(json)
    return json as RuleMap
  } catch (e) {
    console.warn('rules load failed', e)
    return CURRENT_RULES
  }
}
