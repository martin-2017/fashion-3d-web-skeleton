import { jsPDF } from 'jspdf'

export function exportTechPack(
  design: { id: string, components: string[] },
  metrics?: { seamLength?: number, screenshot?: string }
) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const margin = 40
  let y = margin

  doc.setFont('helvetica','bold')
  doc.setFontSize(18)
  doc.text('Tech Pack', margin, y); y += 24

  doc.setFontSize(12)
  doc.setFont('helvetica','normal')
  doc.text(`Design ID: ${design.id}`, margin, y); y += 18
  doc.text(`Generated: ${new Date().toLocaleString()}`, margin, y); y += 20

  if (metrics?.screenshot) {
    const w = 360, h = 220
    doc.addImage(metrics.screenshot, 'PNG', margin, y, w, h)
    y += h + 10
  }

  doc.setFont('helvetica','bold')
  doc.text('Components', margin, y); y += 16
  doc.setFont('helvetica','normal')
  design.components.forEach((c, i) => {
    doc.text(`${i+1}. ${c}`, margin+12, y); y += 16
  })

  y += 10
  doc.setFont('helvetica','bold')
  doc.text('BOM (summary)', margin, y); y += 16
  doc.setFont('helvetica','normal')
  doc.text('- BUTTON_4HOLE_12MM x8 (wastage 3%)', margin+12, y); y += 16

  if (metrics?.seamLength !== undefined) {
    y += 10
    doc.setFont('helvetica','bold')
    doc.text('Seam Metrics', margin, y); y += 16
    doc.setFont('helvetica','normal')
    doc.text(`Total seam length (demo units): ${metrics.seamLength.toFixed(2)}`, margin+12, y); y += 16
  }

  y += 10
  doc.setFont('helvetica','bold')
  doc.text('Routing (SKILL-MATERIAL-MACHINE)', margin, y); y += 16
  doc.setFont('helvetica','normal')
  doc.text('- Attach collar: Sew_A_Level2 / Lockstitch_1N_DL7500 / THREAD_60S_WHITE', margin+12, y)

  doc.save('techpack.pdf')
}
