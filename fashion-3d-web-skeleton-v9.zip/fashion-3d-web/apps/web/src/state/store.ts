import create from 'zustand'
import type { DesignPackage } from '@fashion3d/schemas'
import { db } from '../db'
import { exportTechPack } from '../export/techpack'
import { generateRouting } from '../routing'
import { computeSeamMetric } from '../pattern/metrics'

export type Placement = {
  id: string
  anchorBody: string
  anchorComp: string
  position: [number,number,number]
  rotation: [number,number,number,number]
  scale: [number,number,number]
  surface?: { mesh: string, tri: [number,number,number], bary: [number,number,number] } | null
}

type Snapshot = { components: string[]; placements: Placement[] }

let bc: BroadcastChannel | null = null

type State = {
  components: string[]
  placements: Placement[]
  selectedId?: string
  draggingId?: string
  surfaceMode: boolean
  autoPairMirror: boolean
  past: Snapshot[]
  future: Snapshot[]
  startPlacement: (id: string)=>void
  confirmPlacement: (p: Placement)=>void
  cancelPlacement: ()=>void
  undo: ()=>void
  redo: ()=>void
  toggleSurfaceMode: ()=>void
  togglePairMirror: ()=>void
  exportBOM: ()=>void
  exportTechPack: ()=>Promise<void>
  exportTechPackWithShot: (dataUrl: string)=>Promise<void>
  mirrorSelected: ()=>void
  save: ()=>Promise<void>
  loadLast: ()=>Promise<void>
  publish: ()=>void
  startCollab: (room?: string)=>void
  stopCollab: ()=>void
}

function snapshotOf(s: State): Snapshot {
  return { components: [...s.components], placements: JSON.parse(JSON.stringify(s.placements)) }
}

function broadcast(state: State) {
  if (!bc) return
  bc.postMessage({ type:'patch', payload: { components: state.components, placements: state.placements } })
}

export const useStore = create<State>((set, get) => ({
  components: [],
  placements: [],
  surfaceMode: false,
  autoPairMirror: true,
  past: [],
  future: [],
  startPlacement: (id) => set({ draggingId: id, selectedId: id }),
  confirmPlacement: (p) => set(s => {
    const prev = snapshotOf(s as any)
    const next = { components: [...s.components, p.id], placements: [...s.placements, p], draggingId: undefined, past: [...s.past, prev], future: [] } as any
    setTimeout(()=>broadcast(next), 0)
    return next
  }),
  cancelPlacement: () => set({ draggingId: undefined }),
  undo: () => set(s => {
    if (s.past.length === 0) return {}
    const prev = s.past[s.past.length-1]
    const rest = s.past.slice(0, -1)
    const curr = snapshotOf(s as any)
    const next = { components: prev.components, placements: prev.placements, past: rest, future: [...s.future, curr] } as any
    setTimeout(()=>broadcast(next), 0)
    return next
  }),
  redo: () => set(s => {
    if (s.future.length === 0) return {}
    const nextSnap = s.future[s.future.length-1]
    const rest = s.future.slice(0, -1)
    const curr = snapshotOf(s as any)
    const next = { components: nextSnap.components, placements: nextSnap.placements, future: rest, past: [...s.past, curr] } as any
    setTimeout(()=>broadcast(next), 0)
    return next
  }),
  toggleSurfaceMode: () => set(s => ({ surfaceMode: !s.surfaceMode })),
  togglePairMirror: () => set(s => ({ autoPairMirror: !s.autoPairMirror })),
  exportBOM: () => {
    const bom = [
      { component: 'BUTTON_4HOLE_12MM', color: 'White', uom: 'pcs', qty_per: 8, wastage_pct: 3 }
    ]
    const blob = new Blob([JSON.stringify(bom, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'bom.json'
    a.click()
    URL.revokeObjectURL(url)
  },
  exportTechPack: async () => {
    const comps = get().components
    const seam = await computeSeamMetric('/assets/pattern_demo.dxf')
    const pkg: Partial<DesignPackage> = {
      design_id: 'DRAFT_' + Date.now(),
      version: 'v0.0.1',
      components: comps
    }
    exportTechPack({ id: pkg.design_id!, components: comps }, { seamLength: seam.totalLength })
  },
  exportTechPackWithShot: async (dataUrl: string) => {
    const comps = get().components
    const seam = await computeSeamMetric('/assets/pattern_demo.dxf')
    const pkg: Partial<DesignPackage> = {
      design_id: 'DRAFT_' + Date.now(),
      version: 'v0.0.1',
      components: comps
    }
    exportTechPack({ id: pkg.design_id!, components: comps }, { seamLength: seam.totalLength, screenshot: dataUrl } as any)
  },
  mirrorSelected: () => {
    window.dispatchEvent(new CustomEvent('f3d:mirror-selected'))
  },
  save: async () => {
    const id = 'LOCAL_' + new Date().toISOString().replace(/[:.]/g,'-')
    const now = Date.now()
    await db.projects.put({ id, createdAt: now, updatedAt: now, components: get().components, placements: get().placements })
    alert('Saved: ' + id)
  },
  loadLast: async () => {
    const last = await db.projects.orderBy('updatedAt').last()
    if (!last) { alert('No saved project'); return }
    set({ components: last.components, placements: last.placements || [] })
    window.dispatchEvent(new CustomEvent('f3d:rehydrate'))
    alert('Loaded: ' + last.id)
  },
  publish: () => {
    const comps = get().components
    const routing = generateRouting(comps)
    const pkg: Partial<DesignPackage> = {
      design_id: 'DRAFT_' + Date.now(),
      version: 'v0.0.1',
      components: comps,
      routing: routing as any
    }
    alert('Publish (stub)\n' + JSON.stringify(pkg, null, 2))
  },
  startCollab: (room='f3d-room') => {
    if (bc) return
    bc = new BroadcastChannel(room)
    bc.onmessage = (ev) => {
      if (ev.data?.type === 'patch') {
        const { components, placements } = ev.data.payload || {}
        set({ components, placements })
        window.dispatchEvent(new CustomEvent('f3d:rehydrate'))
      }
    }
    // broadcast current state for late joiners
    broadcast(get())
    alert('Joined collab room: ' + room)
  },
  stopCollab: () => {
    if (bc) { bc.close(); bc = null; alert('Left collab room') }
  }
}))
