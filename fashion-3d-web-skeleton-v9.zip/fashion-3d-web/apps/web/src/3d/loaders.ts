import '@babylonjs/loaders/glTF'
import { Scene } from '@babylonjs/core/scene'
import { SceneLoader } from '@babylonjs/core/Loading/sceneLoader'
import { DracoCompression } from '@babylonjs/core/Meshes/Compression/dracoCompression'

const DRACO_BASE = '/libs/draco/'
const MESHOPT_BASE = '/libs/meshopt/'

// Draco config
(DracoCompression as any).Configuration = {
  decoder: {
    wasmUrl: DRACO_BASE + 'draco_decoder.wasm',
    wasmBinaryUrl: DRACO_BASE + 'draco_decoder.wasm',
    fallbackUrl: DRACO_BASE + 'draco_decoder.js'
  }
}

// Meshopt (Babylon looks for window.MeshoptDecoder)
;(window as any).MeshoptDecoder = {
  ready: fetch(MESHOPT_BASE + 'meshopt_decoder.wasm')
    .then(r => r.arrayBuffer())
    .then(buf => WebAssembly.instantiate(buf, {}))
    .then(res => (window as any).MeshoptDecoder = res.instance.exports)
}

export async function importGLTF(scene: Scene, url: string) {
  const result = await SceneLoader.ImportMeshAsync('', '', url, scene)
  return result
}

export async function readGLTFAnchors(url: string) {
  const res = await fetch(url)
  const gltf = await res.json()
  const nodes = gltf.nodes || []
  const anchors = nodes
    .filter((n: any) => n.extras?.anchor)
    .map((n: any) => ({ name: n.name, ...n.extras.anchor }))
  return anchors as Array<{name: string, type: string, compatible: string[], tolerance_mm?: number, priority?: number}>
}

export async function readGLTFAnchorNodes(url: string) {
  const res = await fetch(url)
  const gltf = await res.json()
  const nodes = gltf.nodes || []
  const anchors = nodes
    .filter((n: any) => n.extras?.anchor)
    .map((n: any) => ({
      name: n.name,
      translation: n.translation || [0,0,0],
      rotation: n.rotation || [0,0,0,1],
      scale: n.scale || [1,1,1],
      anchor: n.extras.anchor
    }))
  return anchors as Array<{name:string, translation:number[], rotation:number[], scale:number[], anchor:any}>
}
