let rafId: number | null = null
let last = performance.now()
let frames = 0
let dom: HTMLElement | null = null

export function startFPSMeter(engine: any, scene: any) {
  dom = document.createElement('div')
  dom.className = 'fps'
  dom.textContent = 'FPS: --'
  document.body.appendChild(dom)

  const loop = () => {
    frames++
    const now = performance.now()
    if (now - last >= 1000) {
      const fps = Math.round((frames * 1000) / (now - last))
      dom!.textContent = `FPS: ${fps}`
      frames = 0
      last = now
    }
    rafId = requestAnimationFrame(loop)
  }
  rafId = requestAnimationFrame(loop)
}

export function stopFPSMeter() {
  if (rafId) cancelAnimationFrame(rafId)
  if (dom && dom.parentElement) dom.parentElement.removeChild(dom)
  rafId = null
  dom = null
}
