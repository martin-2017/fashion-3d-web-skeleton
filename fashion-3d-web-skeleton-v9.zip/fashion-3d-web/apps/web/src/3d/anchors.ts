import { MeshBuilder } from '@babylonjs/core/Meshes/meshBuilder'
import { StandardMaterial } from '@babylonjs/core/Materials/standardMaterial'
import { Color3 } from '@babylonjs/core/Maths/math.color'
import { Vector3 } from '@babylonjs/core/Maths/math.vector'
import { TransformNode } from '@babylonjs/core/Meshes/transformNode'
import type { Scene } from '@babylonjs/core/scene'

export type AnchorMeta = {
  name: string
  compatible: string[]
  tolerance: number // world units
  priority?: number
}

export function createAnchor(scene: Scene, parent: TransformNode, pos: Vector3, meta: AnchorMeta) {
  const node = new TransformNode(meta.name, scene)
  node.parent = parent
  node.position = pos.clone()
  ;(node as any).anchorMeta = meta

  const sphere = MeshBuilder.CreateSphere(meta.name + '_viz', { diameter: 0.06 }, scene)
  sphere.parent = node
  sphere.isPickable = true
  const m = new StandardMaterial(meta.name + '_mat', scene)
  m.emissiveColor = new Color3(0.3, 0.6, 1.0)
  m.alpha = 0.85
  sphere.material = m
  return node
}

export function setAnchorVizState(anchorViz: any, state: 'off'|'ok'|'bad') {
  const mat = anchorViz.material as StandardMaterial
  if (!mat) return
  if (state === 'ok') mat.emissiveColor = new Color3(0.2, 1.0, 0.4)
  else if (state === 'bad') mat.emissiveColor = new Color3(1.0, 0.3, 0.3)
  else mat.emissiveColor = new Color3(0.3, 0.6, 1.0)
}
