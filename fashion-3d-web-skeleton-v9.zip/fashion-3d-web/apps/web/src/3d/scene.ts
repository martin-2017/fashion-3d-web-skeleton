import { Scene } from '@babylonjs/core/scene'
import { HemisphericLight } from '@babylonjs/core/Lights/hemisphericLight'
import { ArcRotateCamera } from '@babylonjs/core/Cameras/arcRotateCamera'
import { Vector3, Color4, Quaternion } from '@babylonjs/core/Maths/math.vector'
import { MeshBuilder } from '@babylonjs/core/Meshes/meshBuilder'
import { TransformNode } from '@babylonjs/core/Meshes/transformNode'
import { StandardMaterial } from '@babylonjs/core/Materials/standardMaterial'
import { Color3 } from '@babylonjs/core/Maths/math.color'
import { createBabylonEngine } from './createEngine'
import { useStore } from '../state/store'
import { importGLTF, readGLTFAnchorNodes } from './loaders'
import { COMPONENT_CATALOG } from '../components/catalog'
import { GizmoManager } from '@babylonjs/core/Gizmos/gizmoManager'
import { checkConstraints, BodyContext } from '../constraints'
import type { Placement } from '../state/store'
import '@babylonjs/core/Materials/standardMaterial'
import '@babylonjs/core/Helpers/sceneHelpers'
import '@babylonjs/core/XR/webXRDefaultExperience'

type GhostMeta = {
  id: string
  anchorNames: string[]
  compatibleSet: Set<string>
  tolerance: number
  compAnchorNodes: TransformNode[]
  offsets: Record<string, [number,number,number]>
}
type Ghost = { root: TransformNode, meta: GhostMeta }

let sceneRef: Scene
let gizmos: GizmoManager | null = null
let anchors: TransformNode[] = []
let bodyRoot: TransformNode
let bodyMeshName = 'body_mesh'
let hoverAnchorViz: any | null = null
let hoverBodyAnchor: TransformNode | null = null
let ghost: Ghost | null = null

export async function startAR() {
  if (!sceneRef) return
  // WebXR default experience; will gracefully fail on desktop unsupported
  try {
    await (sceneRef as any).createDefaultXRExperienceAsync({})
  } catch (e) {
    alert('AR not supported on this device/browser')
  }
}

export function initScene(canvas: HTMLCanvasElement) {
  let engineDisposed = false
  let engineRef: any
  const placedRoots = new Map<number, TransformNode>()

  const ctx: BodyContext = { bodyType: 'SHIRT_WOVEN', fabricClass: 'WOVEN_MEDIUM', presentTags: new Set<string>() }

  function vibrate(ms:number){ if (navigator.vibrate) navigator.vibrate(ms) }

  async function createBodyFromGLTF(scene: Scene) {
    bodyRoot = new TransformNode('BODY', scene)
    await importGLTF(scene, '/assets/body_demo.gltf')
    const defNodes = await readGLTFAnchorNodes('/assets/body_demo.gltf')
    const body = MeshBuilder.CreateBox(bodyMeshName, { width: 1.0, height: 1.2, depth: 0.4 }, scene)
    body.parent = bodyRoot
    const m = new StandardMaterial('body_mat', scene)
    m.diffuseColor = new Color3(0.15,0.35,0.55)
    m.alpha = 0.85
    body.material = m
    anchors.length = 0
    for (const n of defNodes) {
      const pos = new Vector3(n.translation[0], n.translation[1], n.translation[2])
      const tol = (typeof n.anchor?.tolerance_mm === 'number') ? n.anchor.tolerance_mm/1000 : 0.12
      const node = new TransformNode(n.name, scene)
      node.parent = bodyRoot
      node.position.copyFrom(pos)
      const sphere = MeshBuilder.CreateSphere(n.name + '_viz', { diameter: 0.06 }, scene)
      sphere.parent = node; sphere.isPickable = true
      const mat = new StandardMaterial(n.name + '_mat', scene); mat.emissiveColor = new Color3(0.3,0.6,1.0); mat.alpha = .85
      sphere.material = mat
      ;(node as any).anchorMeta = { name: n.name, tolerance: tol }
      anchors.push(node)
    }
  }

  async function createGhostFromComponent(scene: Scene, compId: string): Promise<Ghost> {
    const meta = COMPONENT_CATALOG[compId]
    if (!meta) throw new Error('Unknown component: ' + compId)
    const root = new TransformNode('ghost_'+compId, scene)
    const defs = await readGLTFAnchorNodes(meta.gltf)
    const anchorNames = defs.map(d => d.name)
    const compatibleSet = new Set<string>()
    const offsets: Record<string,[number,number,number]> = {}
    let tol = 0.15
    for (const d of defs) {
      (d.anchor?.compatible || []).forEach((x: string) => compatibleSet.add(x))
      if (typeof d.anchor?.tolerance_mm === 'number') tol = Math.min(tol, Math.max(0.05, d.anchor.tolerance_mm / 1000))
      if (d.anchor?.offset_mm && Array.isArray(d.anchor.offset_mm)) offsets[d.name] = d.anchor.offset_mm as [number,number,number]
    }
    if (defs.length === 0) compatibleSet.add('BODY_NECKLINE')
    const { meshes, transformNodes } = await importGLTF(scene, meta.gltf)
    for (const m of meshes) { if (m.name !== '__root__') { m.setParent(root); m.isPickable = false; if ((m as any).material && 'alpha' in (m as any).material) (m as any).material.alpha = 0.6 } }
    for (const t of transformNodes) { if (t.name !== 'ROOT' && t.parent == null) t.parent = root }
    const compAnchorNodes: TransformNode[] = []
    for (const t of transformNodes) if (anchorNames.includes(t.name)) compAnchorNodes.push(t as TransformNode)
    return { root, meta: { id: compId, anchorNames, compatibleSet, tolerance: tol, compAnchorNodes, offsets } }
  }

  function nearestCompatibleBodyAnchor(g: Ghost) {
    return anchors.reduce((acc: any, a) => {
      if (g.meta.compatibleSet.size && !g.meta.compatibleSet.has(a.name)) return acc
      const viz = a.getChildren()[0] as any
      const d = Vector3.Distance(g.root.getAbsolutePosition(), a.getAbsolutePosition())
      const tol = ((a as any).anchorMeta?.tolerance ?? g.meta.tolerance)
      if (d <= tol && (!acc || d < acc.dist)) return { viz, a, dist: d }
      return acc
    }, null as any)
  }

  function chooseClosestCompAnchorTo(target: TransformNode, compAnchors: TransformNode[]) {
    let best: { node: TransformNode, dist: number } | null = null
    for (const ca of compAnchors) {
      const d = Vector3.Distance(ca.getAbsolutePosition(), target.getAbsolutePosition())
      if (!best || d < best.dist) best = { node: ca, dist: d }
    }
    return best?.node ?? null
  }

  function worldTRS(node: TransformNode) {
    const m = node.getWorldMatrix()
    const pos = m.getTranslation()
    const rot = m.getRotationQuaternion() || Quaternion.Identity()
    const scl = m.getScale()
    return {
      position: [pos.x,pos.y,pos.z] as [number,number,number],
      rotation: [rot.x,rot.y,rot.z,rot.w] as [number,number,number,number],
      scale: [scl.x,scl.y,scl.z] as [number,number,number]
    }
  }

  function attachGizmoTo(node: TransformNode | null) {
    if (!sceneRef) return
    if (!gizmos) {
      gizmos = new GizmoManager(sceneRef)
      gizmos.positionGizmoEnabled = true
      gizmos.rotationGizmoEnabled = true
      gizmos.usePointerToAttachGizmos = false
      if ((gizmos as any).scaleRatio !== undefined) (gizmos as any).scaleRatio = 1.6
    }
    gizmos.attachToMesh(node as any)
  }

  function oppositeLR(name: string) {
    if (name.endsWith('_L')) return name.slice(0,-2) + '_R'
    if (name.endsWith('_R')) return name.slice(0,-2) + '_L'
    return null
  }

  function alignAndAttachToBodyAnchor(g: Ghost, parentAnchor: TransformNode) {
    let chosenCompAnchor = chooseClosestCompAnchorTo(parentAnchor, g.meta.compAnchorNodes) || g.meta.compAnchorNodes[0] || g.root
    const caPos = chosenCompAnchor.getAbsolutePosition(), baPos = parentAnchor.getAbsolutePosition()
    const offset = baPos.subtract(caPos); g.root.position = g.root.position.add(offset)
    const caRot = chosenCompAnchor.rotationQuaternion || Quaternion.Identity()
    const baRot = parentAnchor.rotationQuaternion || Quaternion.Identity()
    const qDelta = baRot.multiply(caRot.conjugate())
    if (!g.root.rotationQuaternion) g.root.rotationQuaternion = Quaternion.Identity()
    g.root.rotationQuaternion = qDelta.multiply(g.root.rotationQuaternion)
    const offMM = g.meta.offsets[chosenCompAnchor.name]; if (offMM) g.root.position.addInPlace(new Vector3(offMM[0]/1000, offMM[1]/1000, offMM[2]/1000))
    g.root.setParent(parentAnchor, true)
    const trs = worldTRS(g.root)
    return { placement: { id: g.meta.id, anchorBody: parentAnchor.name, anchorComp: chosenCompAnchor.name, position: trs.position, rotation: trs.rotation, scale: trs.scale } as Placement }
  }

  function computeBarycentric(p: Vector3, a: Vector3, b: Vector3, c: Vector3) {
    const v0 = b.subtract(a), v1 = c.subtract(a), v2 = p.subtract(a)
    const d00 = Vector3.Dot(v0,v0), d01 = Vector3.Dot(v0,v1), d11 = Vector3.Dot(v1,v1), d20 = Vector3.Dot(v2,v0), d21 = Vector3.Dot(v2,v1)
    const denom = d00 * d11 - d01 * d01
    const v = (d11 * d20 - d01 * d21) / denom
    const w = (d00 * d21 - d01 * d20) / denom
    const u = 1.0 - v - w
    return [u,v,w] as [number,number,number]
  }

  function attachToSurface(g: Ghost, pick: any) {
    const mesh = pick.pickedMesh
    const idx = pick.faceId*3
    const positions = mesh.getVerticesData('position')
    const indices = mesh.getIndices()
    const a = Vector3.FromArray(positions, indices[idx]*3)
    const b = Vector3.FromArray(positions, indices[idx+1]*3)
    const c = Vector3.FromArray(positions, indices[idx+2]*3)
    const bary = computeBarycentric(pick.pickedPoint, a,b,c)

    // Orientation: normal from triangle; tangent as edge AB
    const ab = b.subtract(a).normalize()
    const normal = Vector3.Cross(b.subtract(a), c.subtract(a)).normalize()
    const z = normal; const x = ab; const y = Vector3.Cross(z,x).normalize()
    // Build rotation quaternion from basis (x,y,z) -> world
    const m = new BABYLON.Matrix.FromArray([ x.x, y.x, z.x, 0,  x.y, y.y, z.y, 0,  x.z, y.z, z.z, 0,  0, 0, 0, 1 ])
    const q = new Quaternion(); m.decompose(undefined, q, undefined)
    if (!g.root.rotationQuaternion) g.root.rotationQuaternion = Quaternion.Identity()
    g.root.rotationQuaternion = q

    g.root.position = pick.pickedPoint.clone()
    g.root.setParent(mesh, true)
    const trs = worldTRS(g.root)
    const placement: Placement = { id: g.meta.id, anchorBody: 'SURFACE@'+mesh.name, anchorComp: g.meta.anchorNames[0] || 'ANCHOR', position: trs.position, rotation: trs.rotation, scale: trs.scale, surface: { mesh: mesh.name, tri: [indices[idx], indices[idx+1], indices[idx+2]] as any, bary } }
    return { placement }
  }

  function adaptiveLOD(engine: any, scene: Scene) {
    let accum = 0, frames = 0
    let degraded = false
    scene.onAfterRenderObservable.add(() => {
      accum += engine.getDeltaTime(); frames++
      if (frames >= 30) {
        const ms = accum / frames
        const fps = 1000 / (ms || 1)
        if (!degraded && fps < 45) {
          degraded = true
          // degrade: reduce hardware scaling (bigger value => lower res), disable shadows/gizmo materials heavy
          engine.setHardwareScalingLevel(Math.min(engine.getHardwareScalingLevel()*1.5, 2))
          if (gizmos) gizmos.attachToMesh(null as any)
        } else if (degraded && fps > 58) {
          degraded = false
          engine.setHardwareScalingLevel(Math.max(engine.getHardwareScalingLevel()/1.5, 1))
        }
        accum = 0; frames = 0
      }
    })
  }

  function attachGizmoTo(node: TransformNode | null) {
    if (!sceneRef) return
    if (!gizmos) {
      gizmos = new GizmoManager(sceneRef)
      gizmos.positionGizmoEnabled = true
      gizmos.rotationGizmoEnabled = true
      gizmos.usePointerToAttachGizmos = false
      if ((gizmos as any).scaleRatio !== undefined) (gizmos as any).scaleRatio = 1.6
    }
    gizmos.attachToMesh(node as any)
  }

  ;(async () => {
    const engine = await createBabylonEngine(canvas)
    engineRef = engine
    const scene = new Scene(engine)
    sceneRef = scene
    scene.clearColor = new Color4(0.06, 0.09, 0.16, 1.0)

    const cam = new ArcRotateCamera('cam', Math.PI/4, Math.PI/3, 3, Vector3.Zero(), scene)
    cam.attachControl(canvas, true)
    cam.wheelDeltaPercentage = 0.02
    cam.panningSensibility = 50
    cam.pinchPrecision = 100

    new HemisphericLight('hemi', new Vector3(0.2, 1, 0.2), scene)

    await createBodyFromGLTF(scene)

    adaptiveLOD(engine, scene)

    scene.onPointerMove = () => {
      if (!ghost) return
      const pick = scene.pick(scene.pointerX, scene.pointerY, undefined, false, cam)
      if (pick?.pickedPoint) ghost.root.position = pick.pickedPoint
      const store = useStore.getState()
      if (store.surfaceMode) {
        hoverAnchorViz = null; hoverBodyAnchor = null
        return
      }
      const near = nearestCompatibleBodyAnchor(ghost)
      if (hoverAnchorViz && hoverAnchorViz !== (near?.viz)) {
        const mat = (hoverAnchorViz.material as any); if (mat?.emissiveColor) mat.emissiveColor = new Color3(0.3,0.6,1.0)
      }
      if (near?.viz) {
        const mat = (near.viz.material as any); if (mat?.emissiveColor) mat.emissiveColor = new Color3(0.2,1.0,0.4)
      }
      hoverAnchorViz = near?.viz || null
      hoverBodyAnchor = near?.a || null
    }

    scene.onPointerDown = async () => {
      const store = useStore.getState()
      if (ghost) {
        if (store.surfaceMode) {
          const pick = scene.pick(scene.pointerX, scene.pointerY, (m)=>m.name===bodyMeshName)
          if (!pick?.hit) { alert('Tap lên bề mặt BODY để gắn'); return }
          const { placement } = attachToSurface(ghost, pick)
          ;(ghost.root as any).isPlaced = true
          store.confirmPlacement(placement)
          attachGizmoTo(ghost.root)
          ghost = null; return
        }
        if (!hoverBodyAnchor) { alert('No compatible anchor nearby'); return }
        const { placement } = alignAndAttachToBodyAnchor(ghost, hoverBodyAnchor)
        ;(ghost.root as any).isPlaced = true
        store.confirmPlacement(placement)
        attachGizmoTo(ghost.root)
        const opp = oppositeLR(hoverBodyAnchor.name)
        if (store.autoPairMirror && opp) {
          const target = anchors.find(a => a.name === opp)
          if (target) {
            const g2 = await createGhostFromComponent(scene, placement.id)
            const { placement: pl2 } = alignAndAttachToBodyAnchor(g2, target)
            ;(g2.root as any).isPlaced = true
            store.confirmPlacement(pl2)
          }
        }
        ghost = null
        return
      }
      const pick = scene.pick(scene.pointerX, scene.pointerY)
      if (pick?.pickedMesh) {
        let p: any = pick.pickedMesh
        while (p && !(p.isPlaced)) p = p.parent
        if (p && p.isPlaced) attachGizmoTo(p)
      }
    }

    useStore.subscribe(async (s, prev) => {
      if (s.draggingId && (!ghost || ghost.meta.id !== s.draggingId)) {
        if (ghost) { ghost.root.dispose(); ghost = null }
        ghost = await createGhostFromComponent(scene, s.draggingId)
      } else if (!s.draggingId && ghost) {
        ghost.root.dispose(); ghost = null
      }
      if (s.placements !== prev.placements) {
        // naive rebuild: drop & recreate all
        // (left as-is; can be optimized to diff/patch later)
      }
    })

    engine.runRenderLoop(() => scene.render())
    window.addEventListener('resize', () => engine.resize())
  })()

  return () => {
    if ((sceneRef as any) && !engineDisposed) {
      ;(sceneRef.getEngine() as any).dispose()
      engineDisposed = true
    }
  }
}
