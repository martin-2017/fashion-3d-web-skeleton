import { Engine } from '@babylonjs/core/Engines/engine'
let WebGPUEngine: any

export async function createBabylonEngine(canvas: HTMLCanvasElement) {
  const wantWebGPU = localStorage.getItem('f3d:webgpu') === '1' || (!!(navigator as any).gpu)
  if (wantWebGPU) {
    try {
      const mod = await import('@babylonjs/core/Engines/webgpuEngine')
      WebGPUEngine = (mod as any).WebGPUEngine
      const webgpu = new WebGPUEngine(canvas, { deviceDescriptor: { requiredFeatures: ['texture-compression-bc'] } } as any)
      await webgpu.initAsync()
      console.info('[F3D] WebGPU enabled')
      return webgpu
    } catch (e) {
      console.warn('[F3D] WebGPU failed, falling back to WebGL2', e)
    }
  }
  const engine = new Engine(canvas, true, { preserveDrawingBuffer: false, stencil: true, antialias: true })
  return engine
}
