import { useEffect, useRef, useState } from 'react'
import { initScene, startAR } from './3d/scene'
import { Masterlist } from './components/Masterlist'
import { PropertySheet } from './components/PropertySheet'
import { FpsHud } from './components/FpsHud'
import { PatternOverlay } from './pattern/PatternOverlay'
import { useStore } from './state/store'

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [sheetOpen, setSheetOpen] = useState(true)
  const [patternOpen, setPatternOpen] = useState(false)

  const exportBOM = useStore(s => s.exportBOM)
  const exportTechPack = useStore(s => s.exportTechPack)
  const exportTechPackWithShot = useStore(s => s.exportTechPackWithShot)
  const save = useStore(s => s.save)
  const loadLast = useStore(s => s.loadLast)
  const mirrorSelected = useStore(s => s.mirrorSelected)
  const undo = useStore(s => s.undo)
  const redo = useStore(s => s.redo)
  const autoPairMirror = useStore(s => s.autoPairMirror)
  const togglePairMirror = useStore(s => s.togglePairMirror)
  const surfaceMode = useStore(s => s.surfaceMode)
  const toggleSurfaceMode = useStore(s => s.toggleSurfaceMode)
  const startCollab = useStore(s => s.startCollab)
  const stopCollab = useStore(s => s.stopCollab)

  useEffect(() => {
    if (!canvasRef.current) return
    const dispose = initScene(canvasRef.current)
    return () => void dispose()
  }, [])

  const makePDFWithShot = () => {
    const cvs = canvasRef.current!
    const shot = cvs.toDataURL('image/png', 0.9)
    exportTechPackWithShot(shot)
  }

  return (
    <div style={{height:'100%', position:'relative'}}>
      <div className="masterlist"><Masterlist /></div>
      <canvas ref={canvasRef} />
      <FpsHud />
      {patternOpen && <PatternOverlay onClose={()=>setPatternOpen(false)} />}
      <div className={`sheet ${sheetOpen ? 'open':''}`}>
        <PropertySheet onClose={()=>setSheetOpen(false)} />
      </div>
      <div className="bottom-bar">
        <button className="btn" onClick={()=>setSheetOpen(s=>!s)}>
          {sheetOpen ? 'Hide Properties' : 'Show Properties'}
        </button>
        <div style={{display:'flex', gap:8, flexWrap:'wrap', justifyContent:'flex-end'}}>
          <button className="btn" onClick={undo}>Undo</button>
          <button className="btn" onClick={redo}>Redo</button>
          <label className="btn" style={{display:'inline-flex', alignItems:'center', gap:6}}>
            <input type="checkbox" checked={autoPairMirror} onChange={togglePairMirror} />
            Auto Pair Mirror
          </label>
          <label className="btn" style={{display:'inline-flex', alignItems:'center', gap:6}}>
            <input type="checkbox" checked={surfaceMode} onChange={toggleSurfaceMode} />
            Surface Mode
          </label>
          <button className="btn" onClick={()=>setPatternOpen(true)}>Patterns</button>
          <button className="btn" onClick={mirrorSelected}>Mirror</button>
          <button className="btn" onClick={()=>startCollab(prompt('Room name?', 'f3d-room') || 'f3d-room')}>Collab Join</button>
          <button className="btn" onClick={stopCollab}>Collab Leave</button>
          <button className="btn" onClick={()=>startAR()}>AR</button>
          <button className="btn" onClick={save}>Save</button>
          <button className="btn" onClick={loadLast}>Load Last</button>
          <button className="btn" onClick={exportBOM}>Export BOM</button>
          <button className="btn" onClick={exportTechPack}>Tech Pack PDF</button>
          <button className="btn" onClick={makePDFWithShot}>PDF (with Shot)</button>
          <button className="btn" onClick={()=>useStore.getState().publish()}>Publish</button>
        </div>
      </div>
    </div>
  )
}
