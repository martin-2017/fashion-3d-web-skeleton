import { getRules } from './rules'

export type BodyContext = {
  bodyType: string
  fabricClass: string
  presentTags: Set<string>
}

let worker: Worker | null = null
let workerRulesLoaded = false

export function initConstraintWorker(rules: any) {
  try {
    worker = new Worker(new URL('./workers/rulesWorker.ts', import.meta.url), { type: 'module' })
    worker.postMessage({ type:'load', payload: rules })
    worker.onmessage = (ev: MessageEvent) => {
      if (ev.data?.type === 'loaded') workerRulesLoaded = true
    }
  } catch (e) {
    console.warn('rules worker init failed', e)
  }
}

export async function checkConstraints(compId: string, ctx: BodyContext) {
  if (worker && workerRulesLoaded) {
    return new Promise<{ok:boolean, reasons:string[]}>(resolve => {
      const onmsg = (ev: MessageEvent) => {
        if (ev.data?.type === 'result' && ev.data.compId === compId) {
          worker!.removeEventListener('message', onmsg as any)
          resolve({ ok: !!ev.data.ok, reasons: ev.data.ok ? [] : ['Rule denied (JSONLogic)'] })
        }
      }
      worker!.addEventListener('message', onmsg as any)
      worker!.postMessage({ type:'check', payload: { compId, ctx: { bodyType: ctx.bodyType, fabricClass: ctx.fabricClass, presentTags: Array.from(ctx.presentTags) } } })
    })
  }
  // fallback static rules
  const rules = getRules()
  const t = compId.startsWith('COLLAR') ? 'COLLAR' : compId.startsWith('POCKET') ? 'POCKET' : compId.startsWith('PLACKET') ? 'PLACKET' : 'OTHER'
  const r = (rules as any)[t] || {}
  const reasons: string[] = []
  if (r.allowedBodies && !r.allowedBodies.includes(ctx.bodyType)) reasons.push(`Body ${ctx.bodyType} not allowed for ${t}`)
  if (r.fabricClasses && !r.fabricClasses.includes(ctx.fabricClass)) reasons.push(`Fabric class ${ctx.fabricClass} not allowed for ${t}`)
  if (r.forbidWith) for (const tag of r.forbidWith) if (ctx.presentTags.has(tag)) reasons.push(`Forbidden with ${tag}`)
  return { ok: reasons.length === 0, reasons }
}
