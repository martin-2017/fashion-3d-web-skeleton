import { parseDxfAscii, dxfSeamLength } from './parseDxf'

export async function computeSeamMetric(url: string) {
  try {
    const res = await fetch(url)
    const txt = await res.text()
    const ents = parseDxfAscii(txt)
    const total = dxfSeamLength(ents)
    return { totalLength: total }
  } catch (e) {
    console.warn('computeSeamMetric failed', e)
    return { totalLength: 0 }
  }
}
