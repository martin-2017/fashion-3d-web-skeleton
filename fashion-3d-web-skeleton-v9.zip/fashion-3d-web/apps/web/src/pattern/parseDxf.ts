export type DxfEntity = 
  | { type:'LINE', layer:string, x1:number, y1:number, x2:number, y2:number }
  | { type:'LWPOLYLINE', layer:string, points:Array<[number,number]>, bulges:number[], closed:boolean }

function arcLengthFromBulge(p1:[number,number], p2:[number,number], bulge:number) {
  // bulge b = tan(theta/4); chord length c; theta signed
  const [x1,y1] = p1, [x2,y2] = p2
  const dx = x2-x1, dy=y2-y1
  const c = Math.hypot(dx,dy)
  const theta = 4*Math.atan(bulge || 0)
  if (Math.abs(theta) < 1e-6) return c
  const r = c / (2*Math.sin(theta/2))
  return Math.abs(r * theta)
}

export function parseDxfAscii(text: string) {
  const lines = text.replace(/\r/g,'\n').split(/\n/).map(s=>s.trim())
  let i = 0
  const entities: DxfEntity[] = []
  function nextPair() {
    if (i >= lines.length) return null
    const code = lines[i++]; const value = lines[i++]
    if (value === undefined) return null
    return [code, value] as [string,string]
  }
  while (i < lines.length) {
    const pair = nextPair(); if (!pair) break
    const [code, value] = pair
    if (code === '0' && value === 'LWPOLYLINE') {
      let layer = '0'; let closed = false; const pts: Array<[number,number]> = []; const bulges:number[] = []
      let lastCode = ''
      while (true) {
        const p = nextPair(); if (!p) break
        const [c, v] = p
        if (c === '0') { i -= 2; break } // next entity
        if (c === '8') layer = v
        if (c === '70') closed = (parseInt(v,10) & 1) === 1
        if (c === '10') { lastCode = c; pts.push([parseFloat(v), 0]); bulges.push(0) } // bulge defaults 0 for segment starting at this vertex
        if (c === '20' && lastCode === '10') { const last = pts[pts.length-1]; last[1] = parseFloat(v) }
        if (c === '42') { bulges[bulges.length-1] = parseFloat(v) }
      }
      entities.push({ type:'LWPOLYLINE', layer, points: pts, bulges, closed })
    } else if (code === '0' && value === 'LINE') {
      let layer = '0', x1=0,y1=0,x2=0,y2=0
      while (true) {
        const p = nextPair(); if (!p) break
        const [c, v] = p
        if (c === '0') { i -= 2; break }
        if (c === '8') layer = v
        if (c === '10') x1 = parseFloat(v)
        if (c === '20') y1 = parseFloat(v)
        if (c === '11') x2 = parseFloat(v)
        if (c === '21') y2 = parseFloat(v)
      }
      entities.push({ type:'LINE', layer, x1,y1,x2,y2 })
    }
  }
  return entities
}

export function dxfBounds(ents: DxfEntity[]) {
  let minX=Infinity, minY=Infinity, maxX=-Infinity, maxY=-Infinity
  for (const e of ents) {
    if (e.type==='LINE') {
      minX = Math.min(minX, e.x1, e.x2); minY = Math.min(minY, e.y1, e.y2)
      maxX = Math.max(maxX, e.x1, e.x2); maxY = Math.max(maxY, e.y1, e.y2)
    } else {
      for (const [x,y] of e.points) {
        minX = Math.min(minX, x); minY = Math.min(minY, y)
        maxX = Math.max(maxX, x); maxY = Math.max(maxY, y)
      }
    }
  }
  return { minX, minY, maxX, maxY }
}

export function dxfSeamLength(ents: DxfEntity[]) {
  function segLen(x1:number,y1:number,x2:number,y2:number) { return Math.hypot(x2-x1, y2-y1) }
  let total = 0
  for (const e of ents) {
    if (e.type==='LINE') total += segLen(e.x1,e.y1,e.x2,e.y2)
    else if (e.type==='LWPOLYLINE') {
      for (let i=1;i<e.points.length;i++) {
        const p0 = e.points[i-1], p1 = e.points[i]
        const b = e.bulges[i-1] || 0
        total += (Math.abs(b) > 1e-6) ? arcLengthFromBulge(p0,p1,b) : segLen(p0[0],p0[1], p1[0],p1[1])
      }
      if (e.closed && e.points.length>1) {
        const p0 = e.points.at(-1)!, p1 = e.points[0]
        const b = e.bulges.at(-1) || 0
        total += (Math.abs(b) > 1e-6) ? arcLengthFromBulge(p0,p1,b) : segLen(p0[0],p0[1], p1[0],p1[1])
      }
    }
  }
  return total
}
