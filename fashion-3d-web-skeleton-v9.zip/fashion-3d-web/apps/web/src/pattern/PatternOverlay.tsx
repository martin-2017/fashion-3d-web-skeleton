import { useEffect, useRef, useState } from 'react'

export function PatternOverlay({ onClose }:{ onClose: ()=>void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [length, setLength] = useState<number|null>(null)

  useEffect(() => {
    const worker = new Worker(new URL('../workers/dxfWorker.ts', import.meta.url), { type: 'module' })
    worker.onmessage = (ev: MessageEvent) => {
      if (ev.data?.ok) setLength(ev.data.total)
    }
    worker.postMessage({ type:'computeSeam', url: '/assets/pattern_demo.dxf' })

    ;(async () => {
      // Simple draw via fetch (kept on main thread for demo); could be moved to worker with OffscreenCanvas if needed
      const res = await fetch('/assets/pattern_demo.dxf')
      const txt = await res.text()
      // naive draw: just draw bounding box grid
      const cvs = canvasRef.current!
      const ctx = cvs.getContext('2d')!
      cvs.width = cvs.clientWidth * devicePixelRatio
      cvs.height = cvs.clientHeight * devicePixelRatio
      ctx.clearRect(0,0,cvs.width,cvs.height)
      ctx.strokeStyle = '#334155'
      for (let x=0;x<cvs.width;x+=40) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,cvs.height); ctx.stroke() }
      for (let y=0;y<cvs.height;y+=40) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(cvs.width,y); ctx.stroke() }
    })()

    return () => worker.terminate()
  }, [])

  return (
    <div style={{position:'fixed', left:0, right:0, top:0, bottom:64, background:'#020617cc', backdropFilter:'blur(6px)', padding:12}}>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8}}>
        <strong>Pattern 2D (DXF)</strong>
        <button className="btn" onClick={onClose}>Close</button>
      </div>
      <div style={{display:'grid', gridTemplateColumns:'1fr 320px', gap:12, height:'100%'}}>
        <div style={{background:'#0b1220', border:'1px solid #334155', borderRadius:12, overflow:'hidden'}}>
          <canvas ref={canvasRef} style={{width:'100%', height:'100%'}} />
        </div>
        <div style={{background:'#0b1220', border:'1px solid #334155', borderRadius:12, padding:12}}>
          <div>Seam length (demo units): <strong>{length?.toFixed(2) ?? '--'}</strong></div>
          <div style={{opacity:.8, fontSize:12, marginTop:8}}>Đo chiều dài seam qua Worker (không chặn UI). Có thể nâng cấp parser AAMA/ASTM & OffscreenCanvas.</div>
        </div>
      </div>
    </div>
  )
}
