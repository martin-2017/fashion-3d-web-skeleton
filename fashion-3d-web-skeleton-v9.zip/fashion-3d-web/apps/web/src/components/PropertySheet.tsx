import { useStore } from '../state/store'

export function PropertySheet({ onClose }:{ onClose: ()=>void }) {
  const selected = useStore(s => s.selectedId)
  const draggingId = useStore(s => s.draggingId)
  const cancel = useStore(s => s.cancelPlacement)

  return (
    <div>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <strong>Properties</strong>
        <button className="btn" onClick={onClose}>Close</button>
      </div>
      <div style={{marginTop:8, fontSize:14, opacity:.9}}>
        {draggingId ? (
          <div>
            Placing: <code>{draggingId}</code><br/>
            <small>Move the ghost part over a green anchor and tap/click to attach.</small><br/>
            <button className="btn" onClick={cancel} style={{marginTop:8}}>Cancel</button>
          </div>
        ) : selected ? (
          <div>Editing: <code>{selected}</code> (params UI TBD)</div>
        ) : (
          <div>Select a component or start placement from Masterlist.</div>
        )}
      </div>
    </div>
  )
}
