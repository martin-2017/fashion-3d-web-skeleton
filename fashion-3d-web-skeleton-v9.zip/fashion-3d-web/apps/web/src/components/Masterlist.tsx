import { COMPONENT_CATALOG } from './catalog'
import { useStore } from '../state/store'

export function Masterlist() {
  const start = useStore(s => s.startPlacement)
  const items = Object.entries(COMPONENT_CATALOG)
  return (
    <div>
      <strong>Masterlist</strong>
      <div>
        {items.map(([id, meta]) => (
          <span
            className="chip"
            key={id}
            draggable
            onDragStart={(e)=> e.dataTransfer.setData('text/plain', id)}
            onDoubleClick={()=>start(id)}
            onTouchStart={()=>start(id)}
            title="Double-click / tap to place"
          >{meta.label}</span>
        ))}
      </div>
    </div>
  )
}
