export const COMPONENT_CATALOG: Record<string, { label: string; gltf: string }> = {
  'COLLAR_DEMO@v1.0.0': { label: 'Collar (demo glTF)', gltf: '/assets/collar_demo.gltf' },
  'POCKET_DEMO@v1.0.0': { label: 'Pocket (demo glTF)', gltf: '/assets/pocket_demo.gltf' },
  'PLACKET_DEMO@v1.0.0': { label: 'Placket (demo glTF)', gltf: '/assets/placket_demo.gltf' }
}
